package com.example.busticket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusticketApplicationTests {

	@Test
	void contextLoads() {
	}

}
