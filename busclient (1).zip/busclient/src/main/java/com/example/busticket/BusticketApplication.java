package com.example.busticket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusticketApplication 
{
	public static void main(String[] args) {
		SpringApplication.run(BusticketApplication.class, args);
	}

}
